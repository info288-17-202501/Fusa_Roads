# Libreria MinIO

Esta libreria permite utilizar funciones CRUD de minio
